% MRI
%
% Files
%   ET_MRClean - Remove MRI RF artifacts by comparing neighboring frames
