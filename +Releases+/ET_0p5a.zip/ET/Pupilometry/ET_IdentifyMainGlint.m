function glint = ET_IdentifyMainGlint(B_glint, L_glint, p, roi)
% Select best candidate for main glint from glints list
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 02/22/2013 JMT From scratch
%
% Copyright 2013 California Institute of Technology.
% All rights reserved.

% Init glint return structure
glint.cx    = NaN;
glint.cy    = NaN;
glint.d_eff = NaN;

% Find glint closest to pupil centroid - this is the main glint used
% for tracking
n_glints = length(B_glint);

% Identify glint object
if n_glints > 0
  
  % Gather useful stats from identified regions
  glint_stats = regionprops(L_glint,'Area','Centroid');
  
  % Pupil centroid within ROI
  px = p.cx;
  py = p.cy;
  
  gx = zeros(1,n_glints);
  gy = zeros(1,n_glints);
  
  for bc = 1:n_glints
    
    % Glint centroids coordinates (uncalibrated)
    gx(bc) = glint_stats(bc).Centroid(1);
    gy(bc) = glint_stats(bc).Centroid(2);
    
  end
  
  % Glint areas
  garea = [glint_stats.Area];
  
  % Glint-pupil vector components - glint below pupil has gpvy > 0
  gpvx = gx-px;
  gpvy = gy-py;
  
  % Glint to pupil centroid distance
  d = sqrt(gpvx.^2 + gpvy.^2);
  
  % Select glints by area
  good_glints = find(garea > 20 & garea < 500 & gpvy > 0);
  
  if ~isempty(good_glints)
    
    d_good = d(good_glints);
    
    % Find good glint closest to pupil centroid
    [~, imin] = min(d_good);
    
    % Get original index of best glint
    best_glint = good_glints(imin);
    
    % Load return glint structure
    glint.cx = gx(best_glint);
    glint.cy = gy(best_glint);
    glint.d_eff = sqrt(garea(best_glint)/pi) * 2;
    
  end
  
end
