function [B_glint, L_glint, fr_noglints] = ET_FindRemoveGlints(fr, glint_se, DEBUG)
% Find and remove glints in frame
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 01/18/2013 JMT Extract from ET_FitPupilGlint_Regions.m
%                         Add glint removal
%
% Copyright 2013 California Institute of Technology
% All rights reserved.

% Defaults
if nargin < 3; DEBUG = false; end

% Hard fraction intensity threshold
% Bright regions other than glints can cause problems for percentile
% thresholding
th = 0.75;
bw = fr > th;

% Close glint holes
bw = bwmorph(bw,'close');

% Detect object boundaries
[B_glint, L_glint] = bwboundaries(bw, 'noholes');

% Dilate binary glints
glint_mask = imdilate(bw, glint_se);

% Fill in glints in original frame
fr_noglints = roifill(fr, glint_mask);

if DEBUG
  
  figure(30);
  
  subplot(231), imshow(fr); title('Glint');
  subplot(232), imshow(bw); title('BW');
  subplot(233), imshow(fr_noglints); title('No Glints');
  
end
