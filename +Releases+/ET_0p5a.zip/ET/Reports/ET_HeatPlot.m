function ET_HeatPlot(x, y, xlims, ylims, do_smooth, is_calibrated, h)
% Display heat map and gaze trajectory
%
% USAGE : ET_HeatPlot(p, xmax, ymax, do_trajectory, do_smooth, is_calibrated, h)
%
% ARGS :
% h = axis handle
% p = pupilometry data structure
% xmax, ymax = axis limits
% do_trajectory = flag for overplotting gaze trajectory on heatmap
% do_smooth = flag for smoothing heatmap
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 11/03/2011 JMT From scratch
%          09/18/2012 JMT Integrate with ET GUI
%
% Copyright 2011-2012 California Institute of Technology.
% All rights reserved.

if nargin < 2; x = []; y = []; end
if nargin < 3; xlims = []; end
if nargin < 4; ylims = []; end
if nargin < 5; do_smooth = false; end
if nargin < 6; is_calibrated = false; end
if nargin < 7; h = []; end

% Catch empty limits - autoscale axes
if isempty(xlims); xlims = [min(x)*0.9 max(y)*1.1]; end
if isempty(ylims); ylims = [min(x)*0.9 max(y)*1.1]; end

% Create heat map from pupil trajectory
heat_map = ET_HeatMap(x, y, do_smooth, is_calibrated);

% Create axes if none exist
if isempty(h)
  h = axes;
end

% Display image
imagesc([-1 1], [-1 1], heat_map, 'parent', h);
axis equal xy
set(gca,'XLim',xlims,'YLim',ylims);

% Add grid at 10%, 50%, 90% to each axis if calibrated (x and y max = 100%)
if is_calibrated

  % Vertical grid lines
  line(0.8 * [-1 -1 NaN 0 0 NaN 1 1], [-1 1 NaN -1 1 NaN -1 1], 'color', 'w');
  
  % Horizontal grid lines
  line([-1 1 NaN -1 1 NaN -1 1], 0.8 * [-1 -1 NaN 0 0 NaN 1 1], 'color', 'w');
  
end
