function ET_PupilometryReport(gaze_dir, cal_pupils, cal_model, gaze_pupils)
% Create an HTML report for a pupilometry run
% - calibration or gaze tracking
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech 
% DATES  : 01/28/2013 JMT From scratch
%
% Copyright 2013 California Institute of Technology
% All rights reserved.

% HTML report filename
report_file = fullfile(gaze_dir,'Report.html');

fd = fopen(report_file,'w');
if fd < 0
  fprintf('Could not open %s to write\n', report_file);
  return
end

% Write HTML header
fprintf(fd,'<html><head></head><body>\n');

%% Calibration Report

fprintf(fd,'<h1>CALIBRATION</h1>\n');

% Calculate basic pupilometry stats
cal_stats = ET_PupilometryStats(cal_pupils);

fprintf(fd,'<h2>Calibration Statistics</h2>\n');
fprintf(fd,'<table>\n');
fprintf(fd,'<tr><td>Video duration <td>%0.3f seconds\n', cal_stats.t_dur);
fprintf(fd,'<tr><td>Video rate <td>%0.3f fps\n', cal_stats.fps);
fprintf(fd,'</table>\n');

% Calibration figure
fprintf(fd,'<h2>Calibration Heatmap<h2>\n');
fprintf(fd,'<img src=calibration.png width=512>\n');

%% Gaze Pupilometry Report

fprintf(fd,'<h1>GAZE</h1>\n');

% Calculate basic pupilometry stats
gaze_stats = ET_PupilometryStats(cal_pupils);

fprintf(fd,'<h2>Gaze Statistics</h2>\n');
fprintf(fd,'<table>\n');
fprintf(fd,'<tr><td>Video duration <td>%0.3f seconds\n', gaze_stats.t_dur);
fprintf(fd,'<tr><td>Video rate <td>%0.3f fps\n', gaze_stats.fps);
fprintf(fd,'</table>\n');

% Close HTML page
fprintf(fd,'</body></hmtl>\n');

% Tidy up
fclose(fd);
