function [heat_map, xm, ym] = ET_HeatMap(x, y, do_smooth, is_calibrated)
% Plot gaze heat map from pupilometry data
%
% USAGE : [heat_map, xm, ym] = ET_HeatMap(pupils, do_smooth)
%
% ARGS :
% pupils = structure array of pupil information for each frame
% do_smooth = smoothing flag (for fixation search)
%
% AUTHOR : Mike Tyszka
% PLACE  : Caltech
% DATES  : 10/15/2011 JMT From scratch

if nargin < 2; do_smooth = 0; end
if nargin < 3; is_calibrated = false; end

% Scale up calibrated coordinates to avoid rounding
if is_calibrated
  x = 50 * x;
  y = 50 * y;
end

% Round coordinates
x = round(x);
y = round(y);

% Heat map capture limits for each axis
if is_calibrated
  min_x = -50;
  max_x = 50;
  min_y = -50;
  max_y = 50;
  nx = 101;
  ny = 101;
else
  min_x = 1;
  min_y = 1;
  max_x = ceil(max(x(:)) * 1.1);
  max_y = ceil(max(y(:)) * 1.1);
  nx = max_x;
  ny = max_y;
end

% Discard out of bounds points
oob = x < min_x | y < min_y | x > max_x | y > max_y;
x(oob) = [];
y(oob) = [];

% Create coordinate vectors for heat map
xm = min_x:max_x;
ym = min_y:max_y;

% Allocate gaze heat map
heat_map = zeros(ny, nx);

% Loop over all pupil centroids
for fc = 1:length(x)
  
  % Offset to minimum bounding box
  x0 = x(fc) - min_x + 1;
  y0 = y(fc) - min_y + 1;
  
  % Add one count to the gaze heat map
  if ~isnan(x0) && ~isnan(y0)
    heat_map(y0,x0) = heat_map(y0,x0) + 1;
    end
  
end

% Apply Gaussian smoothing (sigma = 1 pixel)
if do_smooth
  sigma = 1.0;
  h = fspecial('gaussian',[3 3],sigma);
  heat_map = imfilter(heat_map, h);
end
