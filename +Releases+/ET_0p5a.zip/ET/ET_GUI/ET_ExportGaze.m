function ET_ExportGaze(gaze_dir)
% Export subset of gaze timeseries as space-delimited text into Gaze
% directory

if nargin < 1; return; end

if ~exist(gaze_dir,'dir')
  fprintf('ET : Gaze directory does not exist - returning\n');
  return
end

% Gaze pupilometry file
gaze_mat = fullfile(gaze_dir,'Gaze_Pupils.mat');

if ~exist(gaze_mat,'file')
  fprintf('ET : Gaze_Pupils.mat does not exist - returning\n');
  return
end

% Load gaze pupilometry (single pupils structure array)
fprintf('ET : Loading gaze pupilometry\n');
in = load(gaze_mat);

% Extract essential timeseries
t         = [in.pupils.t];
gaze_x    = [in.pupils.gaze_x];
gaze_y    = [in.pupils.gaze_x];
area_corr = [in.pupils.area_correct];
cx        = [in.pupils.cx];
cy        = [in.pupils.cy];
gx        = [in.pupils.gx];
gy        = [in.pupils.gy];
area      = [in.pupils.area];
blink     = [in.pupils.blink];

% Open text output file
gaze_text = fullfile(gaze_dir,'Gaze_Pupils.txt');
fd = fopen(gaze_text,'w');
if fd < 0
  fprintf('ET : Could not open %s to write\n', gaze_text);
  return
end

fprintf('ET : Exporting gaze pupilometry to %s\n', gaze_text);

% Write column headers
fprintf(fd,'%-10s%-10s%-10s%-10s%-10s%-10s%-10s%-10s%-10s%-10s\n',...
  'Time_s','gaze_x','gaze_y','area_corr','cx','cy','gx','gy','area','blink');

for tc = 1:length(t)
  fprintf(fd,'%-10.3f%-10.3f%-10.3f%-10.3f%-10.3f%-10.3f%-10.3f%-10.3f%-10.3f%-10d\n',...
    t(tc),gaze_x(tc),gaze_y(tc),area_corr(tc),...
    cx(tc),cy(tc),gx(tc),gy(tc),area(tc),blink(tc));
end

% Clean up
fclose(fd);

fprintf('ET : Export complete\n');
