function ET_RunWorkFlow(handles)
% Run complete eye tracking workflow
% - make sure that all called functions save their own data and can be used
%   without the GUI
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 09/12/2012 JMT From scratch
%
% Copyright 2012 California Institute of Technology
% All rights reserved.

%% Calibration pupilometry

if exist(handles.cal_pupils_file,'file')
  
  % Load calibration pupilometry
  fprintf('ET : Loading calibration pupilometry\n');
  in = load(handles.cal_pupils_file, 'pupils');
  cal_pupils = in.pupils;
  
else
  
  % Run calibration pupilometry
  % Results are saved to the Gaze directory
  fprintf('ET : Running calibration pupilometry\n');
  
  % Get info from GUI
  vfile  = handles.cal_video_path;
  roi    = handles.roi;
  p_init = handles.p_run;
  
  options.pupils_file   = handles.cal_pupils_file;
  options.video_outfile = fullfile(handles.gaze_dir,'Cal_Pupils');
  options.progress_axes = handles.Eye_Video_Axes;
  options.progress_bar  = handles.Progress_Bar;
  options.gaze_axes     = handles.Gaze_Axes;
  options.pd_range      = handles.pd_range;
  options.do_mrclean    = false;
  options.verbose       = false;
  
  % Run pupilometry on calibration video
  cal_pupils = ET_Video_Pupilometry(vfile, roi, p_init, [], options);
  
  % Update GUI checks
  handles = ET_CheckFiles(handles);
  
end

%% Calibration model

if exist(handles.cal_model_file,'file')
  
  % Load calibration model
  fprintf('ET : Loading calibration model\n');
  in = load(handles.cal_model_file, 'cal_model');
  cal_model = in.cal_model;
  
else
  
  % Calculate calibration model and add to handles
  fprintf('ET : Creating calibration model\n');
  
  % Output directory for calibration images
  out_dir = handles.gaze_dir;
  
  % Run autocalibration
  cal_model = ET_AutoCalibrate(cal_pupils, out_dir);
  
  % Return if ET_Cal is empty (problem with auto calibration)
  if isempty(cal_model.C)
    fprintf('ET : *** Problem creating calibration model\n');
    return
  end
  
  % Save calibration model
  save(handles.cal_model_file, 'cal_model');
  
  % Update GUI checks
  handles = ET_CheckFiles(handles);
  
end

%% Gaze video analysis

if exist(handles.gaze_pupils_file,'file')
  
  % Load gaze pupilometry
  try
    in = load(handles.gaze_pupils_file, 'gaze_pupils');
    gaze_pupils = in.gaze_pupils;
  catch GAZE_PUPILS_LOAD
    fprintf('ET : *** Problem loading gaze pupilometry data\n');
  end
  
else
  
  % Get gaze video filename from GUI
  vfile = handles.gaze_video_path;
  
  % Initialize gaze video, ROI and update GUI
  handles = ET_InitVideo(vfile, handles);
  
  roi          = handles.roi;
  p_init       = handles.p_run;
  
  options.pupils_file   = handles.gaze_pupils_file;
  options.video_outfile = fullfile(handles.gaze_dir,'Gaze_Pupils');
  options.progress_axes = handles.Eye_Video_Axes;
  options.progress_bar  = handles.Progress_Bar;
  options.gaze_axes     = handles.Gaze_Axes;
  options.pd_range      = handles.pd_range;
  options.verbose       = false;
  
  % Only check MR clean flag for gaze movie analysis
  options.do_mrclean    = get(handles.MRClean_Popup,'Value') == 2;
  
  % Run pupilometry on calibration video
  gaze_pupils = ET_Video_Pupilometry(vfile, roi, p_init, cal_model.C, options);
  
end

% TODO - analyze gaze results and create report

% Write pupilometry report
report_file = fullfile(handles.gaze_dir,'Report.html');
ET_PupilometryReport(handles.gaze_dir, cal_pupils, cal_model, gaze_pupils);

