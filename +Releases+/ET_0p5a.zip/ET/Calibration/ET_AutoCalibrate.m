function cal_model = ET_AutoCalibrate(cal_pupils, out_dir)
% Calculate video to gaze calibration model
%
% cal_model = ET_AutoCalibrate(cal_pupils)
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 10/15/2011 JMT From scratch
%          09/14/2012 JMT Integrate with ET GUI
%          01/31/2013 JMT Return to standalone function
%
% Copyright 2012 California Institute of Technology
% All rights reserved.

% Default args
if nargin < 2; out_dir = pwd; end

% Init return argument
cal_model.C = [];
cal_model.fixations = [];

%% Identify raw fixations in pupilometry timeseries

raw_fix = ET_FindFixations_Heat(cal_pupils);

% Sort fixations
[fx, fy] = ET_SortFixations(raw_fix);

% Biquadratic fit to calibration fixations
C = ET_CalibrationFit(fx, fy);

% Save results in structure
cal_model.C         = C;
cal_model.fixations = raw_fix;
cal_model.fx        = fx;
cal_model.fy        = fy;

%% Apply calibration to raw fixations

% Extract pupil centroids
x = [cal_pupils.cx];
y = [cal_pupils.cy];
[gaze_x, gaze_y] = ET_ApplyCalibration(x, y, C);

%% Plot raw and calibrated heat maps with used fixations

% Create a new hidden figure
hf = figure(100);
set(hf,'Visible','off');

clf; colormap(hot)

% Raw fixations and calibration points
subplot(121)

% Fixation area limits in video frame
xmin = min(fx) * 0.9; xmax = max(fx) * 1.1;
ymin = min(fy) * 0.9; ymax = max(fy) * 1.1;

% Smoothed heatmap
imagesc(raw_fix.hmap)
axis equal ij
set(gca,'XLim',[xmin xmax],'YLim',[ymin ymax]);

% Overlay calibration points
hold on
for fc = 1:length(fx)
  plot(fx(fc), fy(fc), 'go', 'markersize', 20);
end
hold off

% Calibrated fixations
h2 = subplot(122);

% Draw calibrated heat map into subplot
ET_HeatPlot(gaze_x, gaze_y, [-1 1], [-1 1], true, true, h2);

% Print figure
cal_png = fullfile(out_dir,'calibration.png');
fprintf('ET : Printing calibration figure to %s\n', cal_png);
print(hf, cal_png, '-dpng', '-r200');

% Close figure
close(hf);

