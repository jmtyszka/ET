function [gaze_x, gaze_y] = ET_ApplyCalibration(x, y, C)
% Apply calibrated correction to raw pupil centroids or pupil-glint vectors
%
% ARGS:
% p = pupil structure array
% C = calibration transform matrix
% FoR = frame of reference ['glint-pupil']
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 11/01/2011 JMT From scratch
%          02/27/2013 JMT Simplify arguments and returns
%
% Copyright 2011-2013 California Institute of Technology.
% All rights reserved.

% Number of sampled centroids
n = length(x);

% Model order from C
model_order = size(C,2);

switch model_order
  
  case 3 % Bilinear
    
    % Construct bilinear R
    R = [x; y; ones(1,n)];
    
  case 6 % Biquadratic

    % Additional binomial coordinates
    x2 = x .* x;
    y2 = y .* y;
    xy = x .* y;
    
    % Construct biquadratic R
    R = [x2; xy; y2; x; y; ones(1,n)];

end

% Apply transformation
R0 = C * R;

% Unpack corrected matrix
gaze_x = R0(1,:);
gaze_y = R0(2,:);
