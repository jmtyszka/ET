function fixations = ET_FindFixations_Heat(pupils)
% Identify fixations in spatial domain using heatmap
%
% USAGE : ET_Fix = ET_FindFixations_Heat(pupils, out_dir)
%
% ARGS :
% pupils  = pupilometry structure array
%
% RETURNS :
% fixations = fixations structure
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 10/15/2011 JMT From scratch
%          11/01/2011 JMT Add verbosity and graphing
%          11/15/2011 JMT Switch from heat map to timeseries analysis
%          09/14/2012 JMT Integrate with ET GUI
%          02/01/2013 JMT Return to standalone operation. Add targets
%
% Copyright 2011-2013 California Institute of Technology.
% All rights reserved.

% Flags
DEBUG = true;

% Init return structure
fixations = [];

% Create heatmap over all frames
hmap = ET_HeatMap(pupils, true);

% Size of heatmap
[ny,nx] = size(hmap);

% Binarize heatmap
hmap = hmap / max(hmap(:));
th = graythresh(hmap);
bw = hmap > th;

% Shrink fixation heat to points
bw = bwmorph(bw,'shrink',Inf);

% Get coordinates of superthreshold pixels
[fy, fx] = ind2sub([ny nx], find(bw));
