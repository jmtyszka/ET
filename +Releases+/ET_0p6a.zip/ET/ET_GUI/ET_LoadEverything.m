function handles = ET_LoadEverything(handles)
% Load all available data and results once calibration video has been selected
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 12/18/2012 JMT Extract from ET.m
%
% Copyright 2013 California Institute of Technology
% All rights reserved.

% Open a file browser
[fname, dir_name] = uigetfile({'*.mov;*.avi;*.mpg','Supported video formats'},...
  'Select calibration video file');
if isequal(fname,0) || isequal(dir_name,0)
  return
end

% Parse filename stub from calibration video filename
% Expecting filenames of form *_Cal.* and *_Gaze.*
[~, Study_Name, Video_Ext] = fileparts(fname);
Study_Name = Study_Name(1:(end-4));

% Save study name (prefix for video file names)
handles.Study_Name = Study_Name;

% Fill GUI file and path fields
set(handles.CWD,       'String', dir_name);
set(handles.Cal_Video_File, 'String', [Study_Name '_Cal' Video_Ext]);
set(handles.Gaze_Video_File, 'String', [Study_Name '_Gaze' Video_Ext]);

% Check whether videos and analysis files exist for this selection
% This function also fills handles fields with data file names
handles = ET_CheckFiles(handles);

% Clear any previous ROIs
if isfield(handles,'roi')
  handles = rmfield(handles,'roi');
end

% Init video, ROI and update GUI
handles = ET_InitVideo(handles.cal_video_path, handles);

% Init gaze plot axes
ET_PlotGaze([], handles.Gaze_Axes, 'init');
