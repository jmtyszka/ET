function ET_RunWorkFlow(handles)
% Run complete eye tracking workflow
% - make sure that all called functions save their own data and can be used
%   without the GUI
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 09/12/2012 JMT From scratch
%
% Copyright 2012 California Institute of Technology
% All rights reserved.

fprintf('\n');
fprintf('----------------------------\n');
fprintf('ET : Starting workflow at %s\n', datestr(now));

%% Calibration pupilometry

if exist(handles.cal_pupils_file,'file')
  
  % Load calibration pupilometry
  fprintf('ET : Loading calibration pupilometry\n');
  in = load(handles.cal_pupils_file, 'pupils');
  cal_pupils = in.pupils;
  
else
  
  % Run calibration pupilometry
  % Results are saved to the Gaze directory
  fprintf('ET : Running calibration pupilometry\n');
  
  % Get info from GUI
  vfile  = handles.cal_video_path;
  roi    = handles.roi;
  p_init = handles.p_run;
  
  options.pupils_file   = handles.cal_pupils_file;
  options.video_outfile = fullfile(handles.gaze_dir,'Cal_Pupils');
  options.progress_axes = handles.Eye_Video_Axes;
  options.progress_bar  = handles.Progress_Bar;
  options.gaze_axes     = handles.Gaze_Axes;
  options.pd_range      = handles.pd_range;
  options.do_mrclean    = false;
  options.verbose       = false;
  
  % Run pupilometry on calibration video
  cal_pupils = ET_Video_Pupilometry(vfile, roi, p_init, [], options);
  
  % Update GUI checks
  handles = ET_CheckFiles(handles);
  
end

%% Calibration model

if exist(handles.calibration_file,'file')
  
  % Load calibration model
  fprintf('ET : Loading calibration model\n');
  in = load(handles.calibration_file, 'calibration');
  calibration = in.calibration;
  
else
  
  % Calculate calibration model and add to handles
  fprintf('ET : Creating calibration model\n');
  
  % Run autocalibration
  calibration = ET_AutoCalibrate([cal_pupils.px], [cal_pupils.py]);
  
  % Return if ET_Cal is empty (problem with auto calibration)
  if isempty(calibration.C)
    fprintf('ET : *** Problem creating calibration model\n');
    return
  end
  
  % Save calibration model
  save(handles.calibration_file, 'calibration');
  
  % Update GUI checks
  handles = ET_CheckFiles(handles);
  
end

%% Gaze video analysis

if exist(handles.gaze_pupils_file,'file')
  
  % Load gaze pupilometry
  try
    fprintf('ET : Loading gaze pupilometry\n');
    in = load(handles.gaze_pupils_file, 'pupils');
    gaze_pupils = in.pupils;
  catch GAZE_PUPILS_LOAD
    fprintf('ET : *** Problem loading gaze pupilometry data\n');
  end
  
else
  
  % Get gaze video filename from GUI
  vfile = handles.gaze_video_path;
  
  % Initialize gaze video, ROI and update GUI
  handles = ET_InitVideo(vfile, handles);
  
  roi          = handles.roi;
  p_init       = handles.p_run;
  
  options.pupils_file   = handles.gaze_pupils_file;
  options.video_outfile = fullfile(handles.gaze_dir,'Gaze_Pupils');
  options.progress_axes = handles.Eye_Video_Axes;
  options.progress_bar  = handles.Progress_Bar;
  options.gaze_axes     = handles.Gaze_Axes;
  options.pd_range      = handles.pd_range;
  options.verbose       = false;
  
  % Only check MR clean flag for gaze movie analysis
  options.do_mrclean    = get(handles.MRClean_Popup,'Value') == 2;
  
  % Run pupilometry on calibration video
  gaze_pupils = ET_Video_Pupilometry(vfile, roi, p_init, calibration.C, options);
  
end

%% Run spike and drift corrections

% Sampling interval
t = [gaze_pupils.t];
dt = t(2) - t(1);

% Uncorrected gaze timeseries
x = [gaze_pupils.gaze_x];
y = [gaze_pupils.gaze_y];
a0 = [gaze_pupils.area_correct];

% Despike and drift correct
gaze_filt = ET_SpikeDriftCorrect(x,y,a0,dt);

%% Create HTML report

ET_PupilometryReport(handles.gaze_dir, cal_pupils, calibration, gaze_pupils, gaze_filt);

%% Export text results

ET_ExportGaze(handles.gaze_dir, gaze_pupils, gaze_filt);

%% Postamble

fprintf('ET : Completed workflow at %s\n', datestr(now));
fprintf('-----------------------------\n');
fprintf('\n');

