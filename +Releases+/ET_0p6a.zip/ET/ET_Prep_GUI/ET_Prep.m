function varargout = ET_Prep(varargin)
% ET_PREP MATLAB code for ET_Prep.fig
%      ET_PREP, by itself, creates a new ET_PREP or raises the existing
%      singleton*.
%
%      H = ET_PREP returns the handle to a new ET_PREP or the handle to
%      the existing singleton*.
%
%      ET_PREP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ET_PREP.M with the given input arguments.
%
%      ET_PREP('Property','Value',...) creates a new ET_PREP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ET_Prep_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ET_Prep_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ET_Prep

% Last Modified by GUIDE v2.5 06-Feb-2013 14:37:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
  'gui_Singleton',  gui_Singleton, ...
  'gui_OpeningFcn', @ET_Prep_OpeningFcn, ...
  'gui_OutputFcn',  @ET_Prep_OutputFcn, ...
  'gui_LayoutFcn',  [] , ...
  'gui_Callback',   []);
if nargin && ischar(varargin{1})
  gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
  [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
  gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before ET_Prep is made visible.
function ET_Prep_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ET_Prep (see VARARGIN)

% Choose default command line output for ET_Prep
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% UIWAIT makes ET_Prep wait for user response (see UIRESUME)
% uiwait(handles.Main_Figure);


% --- Outputs from this function are returned to the command line.
function varargout = ET_Prep_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Go_Button.
function Go_Button_Callback(hObject, eventdata, handles)
% hObject    handle to Go_Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isfield(handles,'roi')
  
  % Run video preparation pipeline
  ET_Prep_Run(handles);
    
else
  
  fprintf('ET_Prep : Please define an ROI before pressing Go\n');
  
end


% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[fname, dname] = uigetfile('*.mov','Select video file to prepare');
if isequal(fname, 0)
  return
end
video_infile = fullfile(dname, fname);

% Update video filename in GUI
set(handles.Video_Infile_Name, 'String', video_infile);

% Create outfile name from infile
[dname, fstub, fext] = fileparts(video_infile);
video_outfile = fullfile(dname, ['Prep_' fstub fext]);
set(handles.Video_Outfile_Name, 'String', video_outfile);

% Get interlaced flag from GUI

% Load first frame from video
v_in = VideoPlayer(video_infile);
fr = ET_LoadFramePair(v_in, 'progressive');
clear v_in

% Setup button down callback function for ROI drawing
handles.roi_cb = @(hObject,eventdata)ET_Prep('Eye_Video_Axes_ButtonDownFcn',hObject,eventdata,guidata(hObject));

% Draw frame in axes
h_im = imshow(fr(:,:,1),'Parent',handles.Eye_Video_Axes);

% Set the image callback to the axes callback
set(h_im, 'ButtonDownFcn', handles.roi_cb);

% Resave handles
guidata(handles.Main_Figure, handles);


% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Close figure
delete(handles.Main_Figure)


% --- Executes on button press in Deinterlace_Check.
function Deinterlace_Check_Callback(hObject, eventdata, handles)
% hObject    handle to Deinterlace_Check (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Deinterlace_Check


% --- Executes on button press in MR_Clean_Check.
function MR_Clean_Check_Callback(hObject, eventdata, handles)
% hObject    handle to MR_Clean_Check (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of MR_Clean_Check


% --- Executes on slider movement.
function Progress_Bar_Callback(hObject, eventdata, handles)
% hObject    handle to Progress_Bar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function Progress_Bar_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Progress_Bar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
% if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%   set(hObject,'BackgroundColor',[.9 .9 .9]);
% end


% --- Executes on mouse press over axes background.
function Eye_Video_Axes_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to Eye_Video_Axes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Call ROI drawing function
ET_UpdateROI(handles);
