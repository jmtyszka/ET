% ET_PREP_GUI
%
% Files
%   ET_Deinterlace - Redraw and save video ROI definition
%   ET_GetROILims  - 
%   ET_Prep        - MATLAB code for ET_Prep.fig
%   ET_Prep_Run    - Run ET video preparation pipeline
%   ET_UpdateROI   - Redraw and save video ROI definition
