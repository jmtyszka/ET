function ET_Prep_Run(handles)
% Run ET video preparation pipeline
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 02/06/2013 JMT From scratch
%
% Copyright 2013 California Institute of Technology.
% All rights reserved.

% Get filenames from GUI
video_infile = get(handles.Video_Infile_Name,'String');
video_outfile = get(handles.Video_Outfile_Name,'String');

% Chop outfile extension
[dname, fname] = fileparts(video_outfile);
video_outfile = fullfile(dname, fname);

% Get flags from GUI
do_deinterlace = logical(get(handles.Deinterlace_Check,'Value'));
do_mrclean = logical(get(handles.MR_Clean_Check,'Value'));

% Set video interlace mode
if do_deinterlace
  imode = 'interlaced';
else
  imode = 'progressive';
end

% Get FPS using Matlab VideoReader (ugh)
try
  v_temp = VideoReader(video_infile);
catch VIDEO_TEMP_OPEN
  fprintf('ET_Prep : Problem opening video for FPS test\n');
  rethrow(VIDEO_TEMP_OPEN)
end

% Get input video info
fps_in = v_temp.FrameRate;
nfr_in = v_temp.NumberOfFrames;

% Destroy VideoReader object
clear v_temp

% Calculate output video info
fps_out = round(fps_in);
nfr_out = nfr_in;
if do_deinterlace
  fps_out = round(2 * fps_out);
  nfr_out = 2 * nfr_out;
end

% Report
fprintf('ET_Prep : Starting ET video preparation at %s\n', datestr(now));
fprintf('ET_Prep : %0.2f fps input\n', fps_in);
fprintf('ET_Prep : %d frames input\n', nfr_in);
fprintf('ET_Prep : %0.2f fps output\n', fps_out);
fprintf('ET_Prep : %d frames output\n', nfr_out);

% Open input video file using VideoPlayer
try
  v_in = VideoPlayer(video_infile);
catch VIDEO_IN_OPEN
  fprintf('ET_Prep : Problem opening input video file\n');
end

% Init output video object - allows existance check later
v_out = [];

%% Setup ROI

% Get ROI pars from handles structure
if isfield(handles,'roi')
  roi = handles.roi;
else
  fprintf('ET_Prep_Run : *** No ROI present in handles\n');
  return
end
roi_xrng = [];
roi_yrng = [];

%% Main video loop

keep_going = true;

tic

while keep_going
  
  % Current frame number
  fc = v_in.FrameNum;
  
  % Update progress slider every 30 frames
  if mod(fc,30) == 0
    set(handles.Progress_Bar,'Value',fc/nfr_in);
    drawnow
  end
  
  % Load frame pair, deinterlace if requested and increment video frame counter
  [fr_pair, keep_going] = ET_LoadFramePair(v_in, imode);
  
  if keep_going
    
    % Clean MR artifacts
    if do_mrclean
      fr_pair = ET_MRClean(fr_pair);
    end
    
    % Loop over frame pair
    for ic = 1:2
      
      % Current frame from interleaved pair
      fr_in = fr_pair(:,:,ic);
      
      if isempty(roi_xrng) || isempty(roi_yrng)
        
        % Get input frame dimensions
        [ny, nx] = size(fr_in);
        
        % Setup ROI pixel ranges
        x1 = fix(roi.x0 * nx) + 1;
        x2 = fix((roi.x0 + roi.w) * nx);
        y1 = fix(roi.y0 * ny) + 1;
        y2 = fix((roi.y0 + roi.h) * ny);
        roi_xrng = x1:x2;
        roi_yrng = y1:y2;
        
      end
      
      % Extract ROI
      fr_roi = fr_in(roi_yrng, roi_xrng);
      
      % Rotate to place upper eyelid at top of frame
      fr_out = rot90(fr_roi, fix(4-(roi.rotate/90)));
      
      % Create output video object if neccessary, otherwise write frame
      if isempty(v_out)
        
        % Create new output video object
        try
          [ny_out, nx_out] = size(fr_out);
          v_out = VideoRecorder(video_outfile, ...
            'Size', [nx_out ny_out], ...
            'Format', 'mov', ...
            'Fps', fps_out);
        catch VIDEO_OUT_OPEN
          fprintf('ET_Prep : Problem opening output video file\n');
          rethrow(VIDEO_OUT_OPEN)
        end
        
      else
        
        % Expand frame to three channels
        fr_out = repmat(fr_out,[1 1 3]);
        
        % Add to output video
        v_out.addFrame(fr_out);
        
      end
      
    end % Frame pair loop
    
  end % If keep going
  
end % Main video frame loop

% Clean up
clear v_in v_out

% Finalize
set(handles.Progress_Bar,'Value',1.0);
fprintf('ET_Prep : Finished preparing video in %0.3f seconds\n', toc);