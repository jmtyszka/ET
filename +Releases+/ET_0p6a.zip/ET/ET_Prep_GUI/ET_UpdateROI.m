function ET_UpdateROI(handles)
% Redraw and save video ROI definition
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 10/18/2012 JMT Extract from ET.m
%
% Copyright 2012 California Institute of Technology
% All rights reserved.

% Return if no thumbnail loaded yet
if ~isfield(handles,'Eye_Video_Axes')
  fprintf('ET_Prep : *** No video frame handle detected\n');
  return
end

% Eye video axes
hh = handles.Eye_Video_Axes;

%% User Defined ROI

% The corners of the ROI are specified with mouse clicks
% The first corner should be superior to the second click anatomically

% First (superior) corner of ROI defined by initial mouse down
p = get(hh,'CurrentPoint');
xy1 = p(1,1:2);
hold on
h1 = plot(xy1(1),xy1(2),'go');
hold off

% Second (inferior) corner of ROI
xy2 = ginput(1);
hold on
h2 = plot(xy2(1),xy2(2),'go');
hold off

%% Determine CCW rotation of ROI

% Diagonal vector
dv = xy2 - xy1;

if abs(dv(1)) > abs(dv(2))
  
  % Landscape ROI
  if dv(2) >= 0
    roi_rotate = 0;
  else
    roi_rotate = 180;
  end

else
  
  % Portrait ROI
  if dv(1) >= 0
    roi_rotate = 90;
  else
    roi_rotate = 270;
  end
  
end

%% Plot ROI overlay on video frame

% Ordered x and y vectors
xx = [xy1(1) xy1(1) xy2(1) xy2(1) xy1(1)];
yy = [xy1(2) xy2(2) xy2(2) xy1(2) xy1(2)];

% Determine top line to thicken
switch roi_rotate
  case {0,180}
    % Landscape
    xx_top = [xy1(1) xy2(1)];
    yy_top = [xy1(2) xy1(2)];
  
  otherwise
    % Portrait
    xx_top = [xy1(1) xy1(1)];
    yy_top = [xy1(2) xy2(2)];
end

% Remove previous ROI and corners
try
  delete(h1);
  delete(h2);
  delete(handles.roi_overlay);
  delete(handles.roi_topline);
catch
end

% Overlay main ROI box
hold on
handles.roi_overlay = plot(xx,yy,'color','y','linewidth',1,'parent',hh);
hold off

% Thicken top side of ROI
hold on
handles.roi_topline = plot(xx_top, yy_top,'color','y','linewidth',4,'parent',hh);
hold off

%% Save ROI

% Get axis limits
xlim = get(hh,'XLim');
ylim = get(hh,'YLim');
nx = diff(xlim);
ny = diff(ylim);

% Normalize ROI coordinates to frame size
xy1 = xy1 ./ [nx ny];
xy2 = xy2 ./ [nx ny];

% Clamp ROI coordinates to range [0,1]
xy1(xy1 < 0) = 0;
xy2(xy2 < 0) = 0;
xy1(xy1 > 1) = 1;
xy2(xy2 > 1) = 1;

% Reorder ROI corners top left - bottom right
% Normalize ROI coordinates to frame (helps with interlaced frames later)
xy0 = min([xy1;xy2]);
wh  = abs(diff([xy1;xy2]));
roi.x0 = xy0(1);
roi.y0 = xy0(2);
roi.w  = wh(1);
roi.h  = wh(2);
roi.rotate = roi_rotate;

% Save new ROI in handles structure and return
handles.roi = roi;
guidata(handles.Main_Figure, handles);